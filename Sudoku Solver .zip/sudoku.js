// Select the grid and buttons
const grid = document.getElementById("sudoku-grid");
const solveBtn = document.getElementById("solve-btn");
const resetBtn = document.getElementById("clear-btn");
const message = document.getElementById("message");

// Generate a 9x9 Sudoku grid dynamically
for (let i = 0; i < 9; i++) {
  for (let j = 0; j < 9; j++) {
    const input = document.createElement("input");
    input.type = "number";
    input.min = "1";
    input.max = "9";
    input.className = "cell";
    input.id = `cell-${i}-${j}`;
    grid.appendChild(input);
  }
}

// Function to get the current grid values as a 2D array
function getGridValues() {
  const values = [];
  for (let i = 0; i < 9; i++) {
    const row = [];
    for (let j = 0; j < 9; j++) {
      const cellValue = document.getElementById(`cell-${i}-${j}`).value;
      row.push(cellValue ? parseInt(cellValue) : 0); // Convert empty cells to 0
    }
    values.push(row);
  }
  return values;
}

// Function to set grid values from a solved puzzle
function setGridValues(values) {
  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      const cell = document.getElementById(`cell-${i}-${j}`);
      cell.value = values[i][j] !== 0 ? values[i][j] : ""; // Set empty cells as blank
    }
  }
}

// Backtracking algorithm to solve Sudoku
function isValid(board, row, col, num) {
  // Check row and column
  for (let x = 0; x < 9; x++) {
    if (board[row][x] === num || board[x][col] === num) return false;
  }

  // Check subgrid
  const startRow = Math.floor(row / 3) * 3;
  const startCol = Math.floor(col / 3) * 3;
  for (let i = startRow; i < startRow + 3; i++) {
    for (let j = startCol; j < startCol + 3; j++) {
      if (board[i][j] === num) return false;
    }
  }

  return true;
}

function solveSudoku(board) {
  for (let row = 0; row < 9; row++) {
    for (let col = 0; col < 9; col++) {
      if (board[row][col] === 0) { // Find an empty cell
        for (let num = 1; num <= 9; num++) { // Try numbers from 1 to 9
          if (isValid(board, row, col, num)) {
            board[row][col] = num;

            if (solveSudoku(board)) return true;

            board[row][col] = 0; // Backtrack
          }
        }
        return false;
      }
    }
  }
  return true;
}

 
// Check if DOM Element Exists
// Event listener for "Solve" button
solveBtn.addEventListener("click", () => {
  const board = getGridValues();

  if (solveSudoku(board)) {
    setGridValues(board);
    message.textContent = "Solved successfully!";
    message.style.color = "green";
  } else {
    message.textContent = "No solution exists!";
    message.style.color = "red";
  }
});

// Event listener for "Reset" button
resetBtn.addEventListener("click", () => {
  // Clear all cells and reset the message
  for (let i = 0; i < 9; i++) {
    for (let j = 0; j < 9; j++) {
      document.getElementById(`cell-${i}-${j}`).value = "";
    }
  }
  message.textContent = "";
});
